using System.Net.Http;
using System.Net.Http.Json;     // GetFromJsonAsync helper
using System.Text;
using System.Text.Json;

namespace WorkoutClientApp
{
    public partial class Form1 : Form
    {
        // One HttpClient for the app's lifetime.
        // *** Set this to YOUR API's address (check the Swagger URL / launchSettings.json). ***
        private static readonly HttpClient _http = new HttpClient
        {
            BaseAddress = new Uri("http://localhost:5216/")
        };

        // case-insensitive so "exercise" from JSON binds to Exercise
        private static readonly JsonSerializerOptions _json =
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true };

        public Form1()
        {
            InitializeComponent();
        }

        // ---- Load (GET all) -------------------------------------------------
        private async void btnLoad_Click(object sender, EventArgs e)
        {
            try
            {
                List<Workout>? workouts = await _http.GetFromJsonAsync<List<Workout>>("api/Workouts");
                dgWorkouts.DataSource = workouts;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load failed: " + ex.Message);
            }
        }

        // ---- Add (POST) -----------------------------------------------------
        private async void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Workout w = ReadInputs();                 // WorkoutId left 0 -> server assigns
                string json = JsonSerializer.Serialize(w);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage resp = await _http.PostAsync("api/Workouts", content);
                resp.EnsureSuccessStatusCode();

                btnLoad_Click(sender, e);                 // refresh grid
                btnClear_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Add failed: " + ex.Message);
            }
        }

        // ---- Update (PUT) ---------------------------------------------------
        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtWorkoutId.Text, out int id))
                {
                    MessageBox.Show("Select a row first.");
                    return;
                }

                Workout w = ReadInputs();
                w.WorkoutId = id;                         // PUT needs id in body to match the url

                string json = JsonSerializer.Serialize(w);
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage resp = await _http.PutAsync($"api/Workouts/{id}", content);
                resp.EnsureSuccessStatusCode();

                btnLoad_Click(sender, e);
                btnClear_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Update failed: " + ex.Message);
            }
        }

        // ---- Delete ---------------------------------------------------------
        private async void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (!int.TryParse(txtWorkoutId.Text, out int id))
                {
                    MessageBox.Show("Select a row first.");
                    return;
                }

                HttpResponseMessage resp = await _http.DeleteAsync($"api/Workouts/{id}");
                resp.EnsureSuccessStatusCode();

                btnLoad_Click(sender, e);
                btnClear_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Delete failed: " + ex.Message);
            }
        }

        // ---- Clear inputs ---------------------------------------------------
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtWorkoutId.Clear();
            txtExercise.Clear();
            txtSets.Clear();
            txtReps.Clear();
            txtWeight.Clear();
            txtDate.Clear();
        }

        // ---- Click a grid row -> copy values into the textboxes -------------
        private void dgWorkouts_SelectionChanged(object sender, EventArgs e)
        {
            if (dgWorkouts.CurrentRow?.DataBoundItem is Workout w)
            {
                txtWorkoutId.Text = w.WorkoutId.ToString();
                txtExercise.Text = w.Exercise;
                txtSets.Text = w.Sets.ToString();
                txtReps.Text = w.Reps.ToString();
                txtWeight.Text = w.Weight.ToString();
                txtDate.Text = w.Date.ToString("yyyy-MM-dd");
            }
        }

        // helper: build a Workout from the textboxes
        private Workout ReadInputs()
        {
            int.TryParse(txtSets.Text, out int sets);
            int.TryParse(txtReps.Text, out int reps);
            int.TryParse(txtWeight.Text, out int weight);
            // if the date box is empty/invalid, default to today
            if (!DateOnly.TryParse(txtDate.Text, out DateOnly date))
                date = DateOnly.FromDateTime(DateTime.Today);

            return new Workout
            {
                Exercise = txtExercise.Text,
                Sets = sets,
                Reps = reps,
                Weight = weight,
                Date = date
            };
        }
    }
}
