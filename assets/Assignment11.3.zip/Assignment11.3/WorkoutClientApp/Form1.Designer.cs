namespace WorkoutClientApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgWorkouts = new DataGridView();
            lblWorkoutId = new Label();
            lblExercise = new Label();
            lblSets = new Label();
            lblReps = new Label();
            lblWeight = new Label();
            lblDate = new Label();
            txtWorkoutId = new TextBox();
            txtExercise = new TextBox();
            txtSets = new TextBox();
            txtReps = new TextBox();
            txtWeight = new TextBox();
            txtDate = new TextBox();
            btnLoad = new Button();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            btnClear = new Button();
            ((System.ComponentModel.ISupportInitialize)dgWorkouts).BeginInit();
            SuspendLayout();
            //
            // dgWorkouts
            //
            dgWorkouts.AllowUserToAddRows = false;
            dgWorkouts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgWorkouts.Location = new Point(12, 12);
            dgWorkouts.Name = "dgWorkouts";
            dgWorkouts.ReadOnly = true;
            dgWorkouts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgWorkouts.MultiSelect = false;
            dgWorkouts.Size = new Size(620, 250);
            dgWorkouts.TabIndex = 0;
            dgWorkouts.SelectionChanged += dgWorkouts_SelectionChanged;
            //
            // labels
            //
            lblWorkoutId.AutoSize = true; lblWorkoutId.Location = new Point(12, 280); lblWorkoutId.Text = "WorkoutId";
            lblExercise.AutoSize = true;  lblExercise.Location = new Point(12, 310);  lblExercise.Text = "Exercise";
            lblSets.AutoSize = true;      lblSets.Location = new Point(12, 340);       lblSets.Text = "Sets";
            lblReps.AutoSize = true;      lblReps.Location = new Point(12, 370);       lblReps.Text = "Reps";
            lblWeight.AutoSize = true;    lblWeight.Location = new Point(12, 400);     lblWeight.Text = "Weight (lbs)";
            lblDate.AutoSize = true;      lblDate.Location = new Point(12, 430);       lblDate.Text = "Date (yyyy-MM-dd)";
            //
            // textboxes
            //
            txtWorkoutId.Location = new Point(140, 277); txtWorkoutId.Name = "txtWorkoutId"; txtWorkoutId.ReadOnly = true; txtWorkoutId.Size = new Size(180, 23);
            txtExercise.Location = new Point(140, 307);  txtExercise.Name = "txtExercise";   txtExercise.Size = new Size(180, 23);
            txtSets.Location = new Point(140, 337);      txtSets.Name = "txtSets";           txtSets.Size = new Size(180, 23);
            txtReps.Location = new Point(140, 367);      txtReps.Name = "txtReps";           txtReps.Size = new Size(180, 23);
            txtWeight.Location = new Point(140, 397);    txtWeight.Name = "txtWeight";        txtWeight.Size = new Size(180, 23);
            txtDate.Location = new Point(140, 427);      txtDate.Name = "txtDate";           txtDate.Size = new Size(180, 23);
            //
            // buttons
            //
            btnLoad.Location = new Point(360, 277);   btnLoad.Size = new Size(120, 30);   btnLoad.Text = "Load Workouts"; btnLoad.Click += btnLoad_Click;
            btnAdd.Location = new Point(360, 313);    btnAdd.Size = new Size(120, 30);    btnAdd.Text = "Add Workout";    btnAdd.Click += btnAdd_Click;
            btnUpdate.Location = new Point(360, 349); btnUpdate.Size = new Size(120, 30); btnUpdate.Text = "Update";      btnUpdate.Click += btnUpdate_Click;
            btnDelete.Location = new Point(490, 313); btnDelete.Size = new Size(120, 30); btnDelete.Text = "Delete";      btnDelete.Click += btnDelete_Click;
            btnClear.Location = new Point(490, 349);  btnClear.Size = new Size(120, 30);  btnClear.Text = "Clear";        btnClear.Click += btnClear_Click;
            //
            // Form1
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(644, 471);
            Controls.Add(dgWorkouts);
            Controls.Add(lblWorkoutId); Controls.Add(lblExercise); Controls.Add(lblSets);
            Controls.Add(lblReps); Controls.Add(lblWeight); Controls.Add(lblDate);
            Controls.Add(txtWorkoutId); Controls.Add(txtExercise); Controls.Add(txtSets);
            Controls.Add(txtReps); Controls.Add(txtWeight); Controls.Add(txtDate);
            Controls.Add(btnLoad); Controls.Add(btnAdd); Controls.Add(btnUpdate);
            Controls.Add(btnDelete); Controls.Add(btnClear);
            Name = "Form1";
            Text = "Workout Tracker - Assignment 11.3";
            ((System.ComponentModel.ISupportInitialize)dgWorkouts).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private DataGridView dgWorkouts;
        private Label lblWorkoutId, lblExercise, lblSets, lblReps, lblWeight, lblDate;
        private TextBox txtWorkoutId, txtExercise, txtSets, txtReps, txtWeight, txtDate;
        private Button btnLoad, btnAdd, btnUpdate, btnDelete, btnClear;
    }
}
