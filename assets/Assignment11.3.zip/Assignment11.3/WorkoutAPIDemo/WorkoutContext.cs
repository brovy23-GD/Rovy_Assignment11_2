using Microsoft.EntityFrameworkCore;

namespace WorkoutAPIDemo
{
    public class WorkoutContext : DbContext
    {
        public WorkoutContext(DbContextOptions<WorkoutContext> options) : base(options)
        {
        }

        public DbSet<Workout> Workouts { get; set; }   // table = Workouts

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // seed one starter row so GET returns data on first run
            modelBuilder.Entity<Workout>().HasData(
                new Workout
                {
                    WorkoutId = 1,
                    Exercise = "Bench Press",
                    Sets = 4,
                    Reps = 8,
                    Weight = 185,
                    Date = new DateOnly(2026, 6, 23)
                }
            );
        }
    }
}
