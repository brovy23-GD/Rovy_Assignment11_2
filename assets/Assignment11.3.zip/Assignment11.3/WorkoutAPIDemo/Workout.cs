namespace WorkoutAPIDemo
{
    // One row in the Workouts table = one logged exercise set.
    public class Workout
    {
        public int WorkoutId { get; set; }                     // primary key (auto-increment)
        public string Exercise { get; set; } = string.Empty;   // e.g. "Bench Press"
        public int Sets { get; set; }                          // number of sets
        public int Reps { get; set; }                          // reps per set
        public int Weight { get; set; }                        // weight in lbs
        public DateOnly Date { get; set; }                     // day performed (yyyy-MM-dd)
    }
}
