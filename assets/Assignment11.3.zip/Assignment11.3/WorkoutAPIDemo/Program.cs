using Microsoft.EntityFrameworkCore;

namespace WorkoutAPIDemo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var connectionString = builder.Configuration.GetConnectionString("WorkoutContext")
                ?? throw new InvalidOperationException("Connection string 'WorkoutContext' not found.");

            builder.Services.AddControllers();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddDbContext<WorkoutContext>(options =>
                options.UseSqlite("Data Source=workouts.db"));

            var app = builder.Build();

            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            // create the SQLite file + schema on first run
            using (var scope = app.Services.CreateScope())
            {
                var db = scope.ServiceProvider.GetRequiredService<WorkoutContext>();
                db.Database.EnsureCreated();
            }

            app.UseAuthorization();
            app.MapControllers();
            app.Run();
        }
    }
}
