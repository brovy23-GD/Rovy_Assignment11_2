# Assignment 11.3 - Workout Web API + WinForms Client

Same pattern as the Movie demo. Domain = **Workout** (Exercise, Sets, Reps, Weight, Date).

## Projects
| Project | Type | Stack |
|---|---|---|
| `WorkoutAPIDemo` | ASP.NET Core Web API | .NET 10, EF Core, SQLite, Swagger |
| `WorkoutClientApp` | WinForms | .NET 10, HttpClient |

## Endpoints (WorkoutsController)
| Verb | Route | Action |
|---|---|---|
| GET | `/api/Workouts` | list all |
| GET | `/api/Workouts/{id}` | get one |
| POST | `/api/Workouts` | create |
| PUT | `/api/Workouts/{id}` | update |
| DELETE | `/api/Workouts/{id}` | delete |

## Run order
1. Start `WorkoutAPIDemo` first (F5). Swagger opens; SQLite `workouts.db` auto-creates with one seed row.
2. Note the port (e.g. `http://localhost:5216`).
3. In `WorkoutClientApp/Form1.cs`, set `BaseAddress` to that exact port.
4. Run `WorkoutClientApp`. Click **Load Workouts**. To Add/Update/Delete: type in the boxes (or click a grid row to edit), hit the button. Grid auto-refreshes.

## Notes
- Date format in the textbox: `yyyy-MM-dd` (e.g. 2026-06-23). Blank/invalid defaults to today.
- API controller is synchronous (matches the scaffolded Movies controller).
- Client uses async/await + JsonSerializer.Serialize + StringContent for POST/PUT.
- WorkoutId is server-assigned; the client box is read-only and fills when you select a row.
